<template>
<div class="wrapper" @click="jump('/')"><text>主页</text></div>
</template>