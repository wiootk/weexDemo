
import { getBaseURL, isAndroid } from '../utils';
const event = weex.requireModule('event');
const navigator = weex.requireModule('navigator')

export default {
    methods: {
        jump(to){
        	// jump:function(to) {
            console.log('to=' + to);
            if (this.$router) {
                this.$router.push(to)
            }
        },
         gotoPage: function(page) {
            var url = getBaseURL(weex) + page + '.js';
            if (typeof window === 'object') {
                url = getBaseURL(weex) + page;
                // url = url.replace(/\.\/dist\/web\//, '/dist/').replace(/\/web\//, '');
                url = url.replace(/\.\/dist\/web\//, '').replace(/\/web\//, '');
            }
            url = url.replace(/\/weex\.html/, '\/index.html');
            // navigator.push({
            //   url: url,
            //   animated: "true"//页面压入时需要动画效果
            // }, event => { console.log(event); })
            event.openURL(url);
        }
    }
}