<template>
    <div class="wrapper" @androidback="back">
        <image :src="logoUrl" class="logo"></image>
        <text class="title" @click="update">Hello {{target}}</text>
        <text class="title">点击次数*2: {{ count | double}} </text>
        <text class="desc">开始干活吧！！！</text>
        <list class="list">
            <cell class="cell" @click="jump('/hello')">
                <text>hello</text>
            </cell>
            <cell class="cell" @click="jump('/')">
                <text>主页</text>
            </cell>
            <cell class="cell" @click="jump('/vuexStore')">
                <text>vuex</text>
            </cell>
            <cell class="cell" @click="axios()">
                <text>fetch</text>
            </cell>
            <cell class="cell" @click="gotoPage('main')">
                <text>main页</text>
            </cell>
        </list>
        <router-view style="flex:1"></router-view>
    </div>
</template>
<script>



export default {
    data: {
        logoUrl: 'http://img1.vued.vanthink.cn/vued08aa73a9ab65dcbd360ec54659ada97c.png',
        target: 'World',
        count: 0
    },
    methods: {
        update: function(e) {
            this.count++;
            this.target = '美女 ' + this.count;
            console.log('target:', this.target)
        },

        back: function() {
            this.$router.back()
        },
        axios: function() {
            // 发送请求
            Vue.fetch({
                method: 'GET',
                url: 'https://cnodejs.org/api/v1/topics',
                data: {},
                type: 'json',
                headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' }
            }, function(res) {
                console.log(JSON.stringify(res));
            })
        },
        created: function() {
          
        }

    }
}
</script>
<style>
.wrapper {
    align-items: center;
    margin-top: 120px;
}

.title {
    padding-top: 40px;
    padding-bottom: 40px;
    font-size: 48px;
}

.logo {
    width: 360px;
    height: 156px;
}

.desc {
    padding-top: 20px;
    color: #888;
    font-size: 24px;
}
</style>