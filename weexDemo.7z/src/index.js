// import App from './index.vue'
// import router from './router'
// import mixins from './mixins'
// Vue.mixin(mixins)
// var vm = new Vue(Vue.util.extend(
//     { el: '#root',
//     router,
//     }, App))
// router.push('/')

import App from './index.vue'
import router from './router'
import mixins from './mixins'
import store from './vuexStore'
import { sync } from 'vuex-router-sync'



const stream = weex.requireModule('stream')
Vue.fetch = stream.fetch;
Vue.prototype.$fetch = stream.fetch;


import * as filters from './filters'
Object.keys(filters).forEach(key => { 
Vue.filter(key, filters[key]) 
})


sync(store, router)
Vue.mixin(mixins)
var vm = new Vue(Vue.util.extend({
    el: '#root',
    store,
    router,
}, App))

router.push('/')