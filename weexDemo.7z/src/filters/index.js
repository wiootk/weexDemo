export function double (a) {
  return a*a
}